import 'package:flutter/material.dart';
import 'package:musicapp/theme/app_theme.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeProvider({bool initialDarkMode = true}) : _isDarkMode = initialDarkMode;

  bool _isDarkMode;

  // ============================================================
  // MODE
  // ============================================================

  bool get isDarkMode => _isDarkMode;

  bool get isLightMode => !_isDarkMode;

  ThemeMode get themeMode {
    return _isDarkMode ? ThemeMode.dark : ThemeMode.light;
  }

  // ============================================================
  // THEME DATA
  // ============================================================

  ThemeData get darkTheme {
    return _buildTheme(
      brightness: Brightness.dark,
      background: AppTheme.darkBackground,
      card: AppTheme.darkCard,
      card2: AppTheme.darkCard2,
      text: AppTheme.darkText,
      subtitle: AppTheme.darkSubtitle,
      outline: const Color(0xFF353535),
    );
  }

  ThemeData get lightTheme {
    return _buildTheme(
      brightness: Brightness.light,
      background: AppTheme.lightBackground,
      card: AppTheme.lightCard,
      card2: AppTheme.lightCard2,
      text: AppTheme.lightText,
      subtitle: AppTheme.lightSubtitle,
      outline: const Color(0xFFD8D2E0),
    );
  }

  // ============================================================
  // THEME BUILDER
  // ============================================================

  ThemeData _buildTheme({
    required Brightness brightness,
    required Color background,
    required Color card,
    required Color card2,
    required Color text,
    required Color subtitle,
    required Color outline,
  }) {
    final bool isDark = brightness == Brightness.dark;

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,

      // ----------------------------------------------------------
      // MAIN COLORS
      // ----------------------------------------------------------
      scaffoldBackgroundColor: background,

      colorScheme: ColorScheme(
        brightness: brightness,

        primary: AppTheme.primary,
        onPrimary: Colors.white,

        secondary: AppTheme.primary,
        onSecondary: Colors.white,

        error: Colors.red,
        onError: Colors.white,

        surface: card,
        onSurface: text,

        outline: outline,
      ),

      // ----------------------------------------------------------
      // APP BAR
      // ----------------------------------------------------------
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: text,
        elevation: 0,
        centerTitle: false,
        surfaceTintColor: Colors.transparent,
      ),

      // ----------------------------------------------------------
      // CARD
      // ----------------------------------------------------------
      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),

      // ----------------------------------------------------------
      // TEXT
      // ----------------------------------------------------------
      textTheme: TextTheme(
        displayLarge: TextStyle(color: text),
        displayMedium: TextStyle(color: text),
        displaySmall: TextStyle(color: text),
        headlineLarge: TextStyle(color: text),
        headlineMedium: TextStyle(color: text),
        headlineSmall: TextStyle(color: text),
        titleLarge: TextStyle(color: text, fontWeight: FontWeight.bold),
        titleMedium: TextStyle(color: text, fontWeight: FontWeight.w600),
        titleSmall: TextStyle(color: text),
        bodyLarge: TextStyle(color: text),
        bodyMedium: TextStyle(color: text),
        bodySmall: TextStyle(color: subtitle),
        labelLarge: TextStyle(color: text),
        labelMedium: TextStyle(color: subtitle),
        labelSmall: TextStyle(color: subtitle),
      ),

      // ----------------------------------------------------------
      // INPUT / TEXT FIELD
      // ----------------------------------------------------------
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: card2,

        hintStyle: TextStyle(color: subtitle),

        labelStyle: TextStyle(color: subtitle),

        prefixIconColor: subtitle,
        suffixIconColor: subtitle,

        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: outline),
        ),

        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: AppTheme.primary, width: 1.5),
        ),

        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),

      // ----------------------------------------------------------
      // ICONS
      // ----------------------------------------------------------
      iconTheme: IconThemeData(color: text),

      // ----------------------------------------------------------
      // DIVIDER
      // ----------------------------------------------------------
      dividerTheme: DividerThemeData(color: outline, thickness: 1),

      // ----------------------------------------------------------
      // SWITCH
      // ----------------------------------------------------------
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith<Color?>((states) {
          if (states.contains(WidgetState.selected)) {
            return Colors.white;
          }

          return subtitle;
        }),
        trackColor: WidgetStateProperty.resolveWith<Color?>((states) {
          if (states.contains(WidgetState.selected)) {
            return AppTheme.primary;
          }

          return outline;
        }),
      ),

      // ----------------------------------------------------------
      // SLIDER
      // ----------------------------------------------------------
      sliderTheme: SliderThemeData(
        activeTrackColor: AppTheme.primary,
        inactiveTrackColor: outline,
        thumbColor: AppTheme.primary,
        overlayColor: AppTheme.primary.withValues(alpha: 0.15),
      ),

      // ----------------------------------------------------------
      // BOTTOM NAVIGATION
      // ----------------------------------------------------------
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: card,
        selectedItemColor: AppTheme.primary,
        unselectedItemColor: subtitle,
        elevation: 0,
      ),

      // ----------------------------------------------------------
      // NAVIGATION BAR - MATERIAL 3
      // ----------------------------------------------------------
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: card,
        indicatorColor: AppTheme.primary.withValues(
          alpha: isDark ? 0.20 : 0.12,
        ),

        iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>((states) {
          if (states.contains(WidgetState.selected)) {
            return IconThemeData(color: AppTheme.primary);
          }

          return IconThemeData(color: subtitle);
        }),

        labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>((states) {
          if (states.contains(WidgetState.selected)) {
            return TextStyle(
              color: AppTheme.primary,
              fontWeight: FontWeight.w600,
            );
          }

          return TextStyle(color: subtitle);
        }),
      ),

      // ----------------------------------------------------------
      // DIALOG
      // ----------------------------------------------------------
      dialogTheme: DialogThemeData(
        backgroundColor: card,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(
          color: text,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        contentTextStyle: TextStyle(color: subtitle, fontSize: 15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),

      // ----------------------------------------------------------
      // SNACKBAR
      // ----------------------------------------------------------
      snackBarTheme: SnackBarThemeData(
        backgroundColor: card2,
        contentTextStyle: TextStyle(color: text),
        actionTextColor: AppTheme.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),

      // ----------------------------------------------------------
      // PROGRESS INDICATOR
      // ----------------------------------------------------------
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: AppTheme.primary,
      ),

      // ----------------------------------------------------------
      // CHECKBOX
      // ----------------------------------------------------------
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith<Color?>((states) {
          if (states.contains(WidgetState.selected)) {
            return AppTheme.primary;
          }

          return Colors.transparent;
        }),
        checkColor: WidgetStateProperty.all(Colors.white),
      ),
    );
  }

  // ============================================================
  // CHANGE MODE
  // ============================================================

  void toggleTheme(bool value) {
    if (_isDarkMode == value) {
      return;
    }

    _isDarkMode = value;
    notifyListeners();
  }

  void setDarkMode() {
    if (_isDarkMode) {
      return;
    }

    _isDarkMode = true;
    notifyListeners();
  }

  void setLightMode() {
    if (!_isDarkMode) {
      return;
    }

    _isDarkMode = false;
    notifyListeners();
  }
}

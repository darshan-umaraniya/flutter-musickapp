import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/track.dart';
import '../providers/music_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/app_bottom_bar.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  int selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();

    final textColor = AppTheme.text(context);
    final subtitleColor = AppTheme.subtitleColor(context);

    final tracks = music.apiTracks;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: AppTheme.backgroundGradient(context),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // HEADER
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Your Library',
                    style: AppTheme.heading.copyWith(color: textColor),
                  ),
                ),
              ),

              // TABS
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: _tab(
                        context,
                        'All Songs',
                        0,
                        tracks.length,
                        textColor,
                        subtitleColor,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _tab(
                        context,
                        'Recently Played',
                        1,
                        music.currentTrack == null ? 0 : 1,
                        textColor,
                        subtitleColor,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 15),

              // CONTENT
              Expanded(
                child: selectedTab == 0
                    ? _allSongs(
                        context,
                        music,
                        tracks,
                        textColor,
                        subtitleColor,
                      )
                    : _recentlyPlayed(context, music, textColor, subtitleColor),
              ),
            ],
          ),
        ),
      ),

      bottomNavigationBar: const AppBottomBar(currentIndex: 1, expanded: true),
    );
  }

  Widget _tab(
    BuildContext context,
    String title,
    int index,
    int count,
    Color textColor,
    Color subtitleColor,
  ) {
    final selected = selectedTab == index;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedTab = index;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primary : AppTheme.card(context),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Center(
          child: Text(
            '$title ($count)',
            style: TextStyle(
              color: selected ? Colors.white : textColor,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }

  Widget _allSongs(
    BuildContext context,
    MusicProvider music,
    List<Track> tracks,
    Color textColor,
    Color subtitleColor,
  ) {
    if (tracks.isEmpty) {
      return _empty(
        Icons.library_music_outlined,
        'No songs available',
        subtitleColor,
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 100),
      itemCount: tracks.length,
      itemBuilder: (context, index) {
        final track = tracks[index];

        final isCurrent = music.currentTrack?.id == track.id;

        return _trackTile(
          context,
          music,
          track,
          isCurrent,
          textColor,
          subtitleColor,
        );
      },
    );
  }

  Widget _recentlyPlayed(
    BuildContext context,
    MusicProvider music,
    Color textColor,
    Color subtitleColor,
  ) {
    final track = music.currentTrack;

    if (track == null) {
      return _empty(Icons.history, 'No recently played songs', subtitleColor);
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 5, 16, 100),
      children: [
        _trackTile(context, music, track, true, textColor, subtitleColor),
      ],
    );
  }

  Widget _trackTile(
    BuildContext context,
    MusicProvider music,
    Track track,
    bool isCurrent,
    Color textColor,
    Color subtitleColor,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isCurrent
            ? AppTheme.primary.withOpacity(.12)
            : AppTheme.card(context),
        borderRadius: BorderRadius.circular(16),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),

        leading: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: track.artworkUrl.isNotEmpty
              ? Image.network(
                  track.artworkUrl,
                  width: 55,
                  height: 55,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => _defaultArtwork(),
                )
              : _defaultArtwork(),
        ),

        title: Text(
          track.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: textColor, fontWeight: FontWeight.w600),
        ),

        subtitle: Text(
          track.artist,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: subtitleColor),
        ),

        trailing: IconButton(
          onPressed: () {
            if (isCurrent && music.isPlaying) {
              music.togglePlayPause();
            } else {
              music.playTrack(track);
            }
          },
          icon: Icon(
            isCurrent && music.isPlaying
                ? Icons.pause_circle
                : Icons.play_circle,
            color: AppTheme.primary,
            size: 38,
          ),
        ),

        onTap: () {
          music.playTrack(track);
        },
      ),
    );
  }

  Widget _defaultArtwork() {
    return Container(
      width: 55,
      height: 55,
      decoration: BoxDecoration(
        gradient: AppTheme.albumGradient,
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Icon(Icons.music_note, color: Colors.white),
    );
  }

  Widget _empty(IconData icon, String message, Color subtitleColor) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 55, color: subtitleColor),
          const SizedBox(height: 15),
          Text(message, style: TextStyle(color: subtitleColor, fontSize: 16)),
        ],
      ),
    );
  }
}
